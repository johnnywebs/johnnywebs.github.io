import{a as t}from"../chunks/entry.ChhCXc0F.js";export{t as start};
