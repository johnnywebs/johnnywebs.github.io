import{a as t}from"../chunks/entry.CKRbwlQD.js";export{t as start};
