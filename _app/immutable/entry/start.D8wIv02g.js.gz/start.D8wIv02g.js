import{a as t}from"../chunks/entry.V8bYntTm.js";export{t as start};
