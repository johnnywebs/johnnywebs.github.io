import{a as t}from"../chunks/entry.DQ18Wpmn.js";export{t as start};
