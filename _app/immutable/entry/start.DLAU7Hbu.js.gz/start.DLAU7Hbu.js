import{a as t}from"../chunks/entry.DbUnPWa_.js";export{t as start};
