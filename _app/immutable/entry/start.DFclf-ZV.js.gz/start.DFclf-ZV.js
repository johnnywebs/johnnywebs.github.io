import{a as t}from"../chunks/entry.j2zn0744.js";export{t as start};
